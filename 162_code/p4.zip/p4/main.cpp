#include "class.h"
//Luis Cervantes
//11/27/2018
//The purpose of this program is to able to run code that is in other files 
//as well being able to use dynamic allocate memory of arrays
//in this program the user gets to enter in their appartment info as well of appartments they got rejected from
//all of this works with the class that is the one that defines it all
int main()
{
	int list_n,t,i;

	appartment code;//Defines all of the variables

	code.data();//This is basically where the entire code runs off from 
	return 0;
}
